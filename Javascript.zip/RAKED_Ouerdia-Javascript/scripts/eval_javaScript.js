function verifierAnnee() {
    // Demande à l'utilisateur de saisir une année
    let annee = prompt("Saisissez une année :");
    // Vérifie que l'entrée est valide (nombre de 1 à 4 chiffres)
    var regex = /^\d{1,4}$/; // Expression régulière : entre 1 et 4 chiffres
    // Vérifie que l'entrée est valide (nombre)
    if (annee && regex.test(annee)) {
        annee = parseInt(annee);

        // Appelle la fonction pour vérifier si l'année est bissextile
        if (isAnneeBissextile(annee)) {
            document.getElementById('resultat').textContent = `${annee} est une année bissextile.`;
        } else {
            document.getElementById('resultat').textContent = `${annee} n'est pas une année bissextile.`;
        }
    } else {
        document.getElementById('resultat').textContent = "Veuillez saisir un nombre valide entre 1 et 4 chiffres.";
    }
}

// Fonction pour vérifier si une année est bissextile
function isAnneeBissextile(annee) {
    return (annee % 4 === 0 && (annee % 100 !== 0 || annee % 400 === 0));
}
// Écouter la soumission du formulaire
document.getElementById('form-client').addEventListener('submit', function(event) {
    event.preventDefault(); // Empêche la soumission réelle du formulaire
    // Récupération des valeurs des champs du formulaire
    const civilite = document.getElementById('civilite').value;
    const nom = document.getElementById('nom').value;
    const prenom = document.getElementById('prenom').value;
    const email = document.getElementById('email').value;
    const telephone = document.getElementById('telephone').value;
    // Vérification si tous les champs sont remplis
    if (!civilite || !nom || !prenom || !email || !telephone) {
        alert("Veuillez remplir tous les champs du formulaire.");
        return; // Arrête l'exécution de la fonction si un champ est vide
    }
    // Vérification que le téléphone est valide : 10 chiffres
    var regexTel = /^\d{10}$/; // Regex pour un numéro de téléphone avec 10 chiffres
    if (!regexTel.test(telephone)) {
        alert("Veuillez entrer un numéro de téléphone valide (10 chiffres).");
        return; // Arrête l'exécution si le numéro de téléphone est invalide
    }

    // Création de l'objet client avec une méthode de présentation
    const client = {
        civilite: civilite,
        nom: nom,
        prenom: prenom,
        email: email,
        telephone: telephone,
        presentation: function() {
            alert(`Bonjour, je suis ${this.civilite} ${this.prenom} ${this.nom}, vous pouvez me contacter sur ${this.email} ou au ${this.telephone}`);
        }
    };

    // Appel de la méthode de présentation
    client.presentation();
});